HOSPITAL MANAGEMENT SYSTEM - CORE JAVA

Requirements:
- JDK 14 or later
- Command line / terminal

Compile from the HospitalManagementSystem folder:
    javac hospital/*.java

Run:
    java hospital.HospitalManagementSystem

The program creates/uses:
- patients.txt
- doctors.txt
- appointments.txt

Use option 9 (Save & Exit) to save records before closing.
