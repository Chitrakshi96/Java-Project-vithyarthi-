package hospital;

public class RecordNotFoundException extends HospitalException {
    public RecordNotFoundException(String message) {
        super(message);
    }
}
