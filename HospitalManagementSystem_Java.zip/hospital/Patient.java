package hospital;

public class Patient extends Person {
    private String disease;
    private String address;

    public Patient(String id, String name, int age, String gender, String contact,
                   String disease, String address) {
        super(id, name, age, gender, contact);
        this.disease = disease;
        this.address = address;
    }

    public String getDisease() { return disease; }
    public String getAddress() { return address; }

    public void setDisease(String disease) { this.disease = disease; }
    public void setAddress(String address) { this.address = address; }

    @Override
    public void displayDetails() {
        System.out.println("Patient ID : " + id);
        System.out.println("Name       : " + name);
        System.out.println("Age        : " + age);
        System.out.println("Gender     : " + gender);
        System.out.println("Contact    : " + contact);
        System.out.println("Disease / Symptoms : " + disease);
        System.out.println("Address    : " + address);
        System.out.println("----------------------------------------");
    }
}
