package hospital;

public class Doctor extends Person {
    private String specialization;
    private String availableSlots;

    public Doctor(String id, String name, int age, String gender, String contact,
                  String specialization, String availableSlots) {
        super(id, name, age, gender, contact);
        this.specialization = specialization;
        this.availableSlots = availableSlots;
    }

    public String getSpecialization() { return specialization; }
    public String getAvailableSlots() { return availableSlots; }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public void setAvailableSlots(String availableSlots) {
        this.availableSlots = availableSlots;
    }

    @Override
    public void displayDetails() {
        System.out.println("Doctor ID       : " + id);
        System.out.println("Name            : " + name);
        System.out.println("Age             : " + age);
        System.out.println("Gender          : " + gender);
        System.out.println("Contact         : " + contact);
        System.out.println("Specialization  : " + specialization);
        System.out.println("Available Slots : " + availableSlots);
        System.out.println("----------------------------------------");
    }
}
