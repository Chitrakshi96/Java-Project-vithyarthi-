package hospital;

public class DoctorUnavailableException extends HospitalException {
    public DoctorUnavailableException(String message) {
        super(message);
    }
}
