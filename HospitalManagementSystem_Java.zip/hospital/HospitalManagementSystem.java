package hospital;

import java.io.IOException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.regex.Pattern;

public class HospitalManagementSystem {
    private static final Scanner scanner = new Scanner(System.in);

    private static final ArrayList<Doctor> doctors = new ArrayList<>();
    private static final ArrayList<Patient> patients = new ArrayList<>();
    private static final ArrayList<Appointment> appointments = new ArrayList<>();

    private static int nextAppointmentNumber = 1;

    public static void main(String[] args) {
        loadData();

        System.out.println("\n========================================");
        System.out.println("       HOSPITAL MANAGEMENT SYSTEM");
        System.out.println("========================================");

        boolean running = true;

        while (running) {
            displayMenu();

            try {
                int choice = Integer.parseInt(scanner.nextLine().trim());

                switch (choice) {
                    case 1 -> addDoctor();
                    case 2 -> addPatient();
                    case 3 -> bookAppointment();
                    case 4 -> cancelAppointment();
                    case 5 -> viewAllAppointments();
                    case 6 -> viewAllPatients();
                    case 7 -> viewAllDoctors();
                    case 8 -> updateAppointmentStatus();
                    case 9 -> {
                        saveData();
                        running = false;
                        System.out.println("Thank you. Program closed.");
                    }
                    default -> System.out.println("Invalid choice. Please enter 1 to 9.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Input error: Please enter a number.");
            } catch (HospitalException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }

        scanner.close();
    }

    private static void displayMenu() {
        System.out.println("\n===== HOSPITAL MANAGEMENT SYSTEM =====");
        System.out.println("1. Add Doctor");
        System.out.println("2. Add Patient");
        System.out.println("3. Book Appointment");
        System.out.println("4. Cancel Appointment");
        System.out.println("5. View All Appointments");
        System.out.println("6. View All Patients");
        System.out.println("7. View All Doctors");
        System.out.println("8. Update Appointment Status");
        System.out.println("9. Save & Exit");
        System.out.print("Enter choice: ");
    }

    private static void addDoctor() throws HospitalException {
        System.out.println("\n--- ADD DOCTOR ---");

        String id = readNonEmpty("Enter Doctor ID       : ");
        if (findDoctor(id) != null) {
            throw new HospitalException("Doctor ID " + id + " already exists.");
        }

        String name = readNonEmpty("Enter Name            : ");
        int age = readAge("Enter Age             : ");
        String gender = readNonEmpty("Enter Gender          : ");
        String contact = readNonEmpty("Enter Contact         : ");
        String specialization = readNonEmpty("Enter Specialization  : ");
        String slots = readNonEmpty("Enter Available Slots : ");

        doctors.add(new Doctor(id, name, age, gender, contact,
                specialization, slots));

        System.out.println("Doctor added successfully.");
    }

    private static void addPatient() throws HospitalException {
        System.out.println("\n--- ADD PATIENT ---");

        String id = readNonEmpty("Enter Patient ID      : ");
        if (findPatient(id) != null) {
            throw new HospitalException("Patient ID " + id + " already exists.");
        }

        String name = readNonEmpty("Enter Name            : ");
        int age = readAge("Enter Age             : ");
        String gender = readNonEmpty("Enter Gender          : ");
        String contact = readNonEmpty("Enter Contact         : ");
        String disease = readNonEmpty("Enter Disease/Symptoms: ");
        String address = readNonEmpty("Enter Address         : ");

        patients.add(new Patient(id, name, age, gender, contact,
                disease, address));

        System.out.println("Patient added successfully.");
    }

    private static void bookAppointment() throws HospitalException {
        System.out.println("\n--- BOOK APPOINTMENT ---");

        String patientId = readNonEmpty("Enter Patient ID : ");
        if (findPatient(patientId) == null) {
            throw new RecordNotFoundException(
                    "No patient found with ID " + patientId + ".");
        }

        String doctorId = readNonEmpty("Enter Doctor ID  : ");
        if (findDoctor(doctorId) == null) {
            throw new RecordNotFoundException(
                    "No doctor found with ID " + doctorId + ".");
        }

        String date = readNonEmpty("Enter Date (dd-mm-yyyy) : ");
        String time = readNonEmpty("Enter Time (HH:mm)      : ");

        validateDate(date);
        validateTime(time);

        for (Appointment a : appointments) {
            boolean sameDoctor = a.getDoctorId().equalsIgnoreCase(doctorId);
            boolean sameDate = a.getDate().equals(date);
            boolean sameTime = a.getTime().equals(time);
            boolean active = a.getStatus().equalsIgnoreCase("BOOKED");

            if (sameDoctor && sameDate && sameTime && active) {
                throw new DoctorUnavailableException(
                        "Doctor " + doctorId + " is already booked at "
                        + time + " on " + date + ".");
            }
        }

        String appointmentId = generateAppointmentId();

        appointments.add(new Appointment(
                appointmentId, patientId, doctorId, date, time, "BOOKED"));

        System.out.println("Appointment booked successfully. Appointment ID: "
                + appointmentId);
    }

    private static void cancelAppointment() throws HospitalException {
        System.out.println("\n--- CANCEL APPOINTMENT ---");

        String id = readNonEmpty("Enter Appointment ID : ");
        Appointment appointment = findAppointment(id);

        if (appointment == null) {
            throw new RecordNotFoundException(
                    "No appointment found with ID " + id + ".");
        }

        appointment.setStatus("CANCELLED");
        System.out.println("Appointment " + id + " cancelled successfully.");
    }

    private static void updateAppointmentStatus() throws HospitalException {
        System.out.println("\n--- UPDATE APPOINTMENT STATUS ---");

        String id = readNonEmpty("Enter Appointment ID : ");
        Appointment appointment = findAppointment(id);

        if (appointment == null) {
            throw new RecordNotFoundException(
                    "No appointment found with ID " + id + ".");
        }

        String status = readNonEmpty(
                "Enter Status (COMPLETED/CANCELLED) : ").toUpperCase();

        if (!status.equals("COMPLETED") && !status.equals("CANCELLED")) {
            throw new InvalidAppointmentException(
                    "Invalid status. Use COMPLETED or CANCELLED.");
        }

        appointment.setStatus(status);
        System.out.println("Appointment status updated successfully.");
    }

    private static void viewAllAppointments() {
        System.out.println("\n--- ALL APPOINTMENTS ---");

        if (appointments.isEmpty()) {
            System.out.println("No appointments found.");
            return;
        }

        for (Appointment appointment : appointments) {
            appointment.displayDetails();
        }
    }

    private static void viewAllPatients() {
        System.out.println("\n--- ALL PATIENTS ---");

        if (patients.isEmpty()) {
            System.out.println("No patients found.");
            return;
        }

        // Person references demonstrate runtime polymorphism.
        ArrayList<Person> people = new ArrayList<>(patients);
        for (Person person : people) {
            person.displayDetails();
        }
    }

    private static void viewAllDoctors() {
        System.out.println("\n--- ALL DOCTORS ---");

        if (doctors.isEmpty()) {
            System.out.println("No doctors found.");
            return;
        }

        // Person references demonstrate runtime polymorphism.
        ArrayList<Person> people = new ArrayList<>(doctors);
        for (Person person : people) {
            person.displayDetails();
        }
    }

    private static String generateAppointmentId() {
        String id;
        do {
            id = "A" + nextAppointmentNumber++;
        } while (findAppointment(id) != null);
        return id;
    }

    private static Doctor findDoctor(String id) {
        for (Doctor doctor : doctors) {
            if (doctor.getId().equalsIgnoreCase(id)) {
                return doctor;
            }
        }
        return null;
    }

    private static Patient findPatient(String id) {
        for (Patient patient : patients) {
            if (patient.getId().equalsIgnoreCase(id)) {
                return patient;
            }
        }
        return null;
    }

    private static Appointment findAppointment(String id) {
        for (Appointment appointment : appointments) {
            if (appointment.getAppointmentId().equalsIgnoreCase(id)) {
                return appointment;
            }
        }
        return null;
    }

    private static String readNonEmpty(String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = scanner.nextLine().trim();

            if (!value.isEmpty()) {
                return value;
            }

            System.out.println("Input cannot be empty.");
        }
    }

    private static int readAge(String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                int age = Integer.parseInt(scanner.nextLine().trim());

                if (age < 0 || age > 120) {
                    System.out.println("Please enter an age between 0 and 120.");
                    continue;
                }

                return age;
            } catch (NumberFormatException e) {
                System.out.println("Input error: Please enter a valid number.");
            }
        }
    }

    private static void validateDate(String date)
            throws InvalidAppointmentException {
        if (!Pattern.matches("\\d{2}-\\d{2}-\\d{4}", date)) {
            throw new InvalidAppointmentException(
                    "Invalid date. Use dd-mm-yyyy format.");
        }

        String[] parts = date.split("-");
        int day = Integer.parseInt(parts[0]);
        int month = Integer.parseInt(parts[1]);

        if (month < 1 || month > 12 || day < 1 || day > 31) {
            throw new InvalidAppointmentException(
                    "Invalid date. Please enter a valid day and month.");
        }
    }

    private static void validateTime(String time)
            throws InvalidAppointmentException {
        if (!Pattern.matches("\\d{2}:\\d{2}", time)) {
            throw new InvalidAppointmentException(
                    "Invalid time. Use HH:mm format.");
        }

        String[] parts = time.split(":");
        int hour = Integer.parseInt(parts[0]);
        int minute = Integer.parseInt(parts[1]);

        if (hour < 0 || hour > 23 || minute < 0 || minute > 59) {
            throw new InvalidAppointmentException(
                    "Invalid time. Use a 24-hour time between 00:00 and 23:59.");
        }
    }

    private static void saveData() {
        try {
            FileManager.saveAll(patients, doctors, appointments);
            System.out.println("All records saved successfully.");
        } catch (IOException e) {
            System.out.println("File error while saving records: "
                    + e.getMessage());
        }
    }

    private static void loadData() {
        try {
            patients.addAll(FileManager.loadPatients());
            doctors.addAll(FileManager.loadDoctors());
            appointments.addAll(FileManager.loadAppointments());

            for (Appointment a : appointments) {
                String id = a.getAppointmentId();
                if (id.length() > 1 && id.substring(1).matches("\\d+")) {
                    int number = Integer.parseInt(id.substring(1));
                    nextAppointmentNumber = Math.max(
                            nextAppointmentNumber, number + 1);
                }
            }
        } catch (IOException e) {
            System.out.println("File error while loading records: "
                    + e.getMessage());
        }
    }
}
