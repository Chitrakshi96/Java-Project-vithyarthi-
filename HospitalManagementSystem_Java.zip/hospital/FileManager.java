package hospital;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class FileManager {
    private static final String PATIENT_FILE = "patients.txt";
    private static final String DOCTOR_FILE = "doctors.txt";
    private static final String APPOINTMENT_FILE = "appointments.txt";

    public static void savePatients(List<Patient> patients) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(PATIENT_FILE))) {
            for (Patient p : patients) {
                bw.write(String.join(",",
                        p.getId(), p.getName(), String.valueOf(p.getAge()),
                        p.getGender(), p.getContact(), p.getDisease(), p.getAddress()));
                bw.newLine();
            }
        }
    }

    public static void saveDoctors(List<Doctor> doctors) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(DOCTOR_FILE))) {
            for (Doctor d : doctors) {
                bw.write(String.join(",",
                        d.getId(), d.getName(), String.valueOf(d.getAge()),
                        d.getGender(), d.getContact(), d.getSpecialization(),
                        d.getAvailableSlots()));
                bw.newLine();
            }
        }
    }

    public static void saveAppointments(List<Appointment> appointments) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(APPOINTMENT_FILE))) {
            for (Appointment a : appointments) {
                bw.write(String.join(",",
                        a.getAppointmentId(), a.getPatientId(), a.getDoctorId(),
                        a.getDate(), a.getTime(), a.getStatus()));
                bw.newLine();
            }
        }
    }

    public static ArrayList<Patient> loadPatients() throws IOException {
        ArrayList<Patient> patients = new ArrayList<>();
        File file = new File(PATIENT_FILE);
        if (!file.exists()) return patients;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] f = line.split(",", -1);
                if (f.length >= 7) {
                    try {
                        patients.add(new Patient(f[0], f[1], Integer.parseInt(f[2]),
                                f[3], f[4], f[5], f[6]));
                    } catch (NumberFormatException ignored) {
                        System.out.println("Skipped invalid patient record: " + line);
                    }
                }
            }
        }
        return patients;
    }

    public static ArrayList<Doctor> loadDoctors() throws IOException {
        ArrayList<Doctor> doctors = new ArrayList<>();
        File file = new File(DOCTOR_FILE);
        if (!file.exists()) return doctors;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] f = line.split(",", -1);
                if (f.length >= 7) {
                    try {
                        doctors.add(new Doctor(f[0], f[1], Integer.parseInt(f[2]),
                                f[3], f[4], f[5], f[6]));
                    } catch (NumberFormatException ignored) {
                        System.out.println("Skipped invalid doctor record: " + line);
                    }
                }
            }
        }
        return doctors;
    }

    public static ArrayList<Appointment> loadAppointments() throws IOException {
        ArrayList<Appointment> appointments = new ArrayList<>();
        File file = new File(APPOINTMENT_FILE);
        if (!file.exists()) return appointments;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] f = line.split(",", -1);
                if (f.length >= 6) {
                    appointments.add(new Appointment(
                            f[0], f[1], f[2], f[3], f[4], f[5]));
                }
            }
        }
        return appointments;
    }

    public static void saveAll(List<Patient> patients, List<Doctor> doctors,
                               List<Appointment> appointments) throws IOException {
        savePatients(patients);
        saveDoctors(doctors);
        saveAppointments(appointments);
    }
}
